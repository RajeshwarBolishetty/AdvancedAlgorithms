#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <vector>
#include <cstdint>

// Custom set of constants for SHA-256
const uint32_t custom_constants[64] = {
    // Constants specific to this implementation
    // ... (unchanged)
};

// Custom SHA-256 function
std::string calculate_custom_sha256(const std::vector<uint8_t>& input) {
    const size_t block_size = 64;
    const size_t digest_size = 32;

    // Prepare the data for processing
    std::vector<uint8_t> data;
    data.reserve(input.size() + 9);

    // Append the input data and padding
    data.insert(data.end(), input.begin(), input.end());
    data.push_back(0x80);

    // Calculate the padding size
    size_t original_size = input.size();
    size_t k = block_size - ((original_size + 1 + 8) % block_size);
    data.insert(data.end(), k, 0);

    // Append the bit length of the original data
    uint64_t bit_length = original_size * 8;
    for (int i = 7; i >= 0; --i) {
        data.push_back(static_cast<uint8_t>((bit_length >> (i * 8)) & 0xFF));
    }

    // Initialize hash values
    uint32_t h[8] = {
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    };

    std::stringstream result; // Move the declaration outside the loop

    // Process data in blocks
    for (size_t i = 0; i < data.size(); i += block_size) {
        // Prepare 64-word message schedule array
        std::vector<uint32_t> w(64, 0);

        // Copy data into message schedule
        for (size_t j = 0; j < 16; ++j) {
            w[j] = (data[i + 4 * j] << 24) | (data[i + 4 * j + 1] << 16) |
                   (data[i + 4 * j + 2] << 8) | data[i + 4 * j + 3];
        }

        // Extend the message schedule
        for (size_t j = 16; j < 64; ++j) {
            uint32_t s0 = (w[j - 15] >> 7) ^ (w[j - 15] >> 18) ^ (w[j - 15] >> 3);
            uint32_t s1 = (w[j - 2] >> 17) ^ (w[j - 2] >> 19) ^ (w[j - 2] >> 10);
            w[j] = w[j - 16] + s0 + w[j - 7] + s1;
        }

        // Initialize hash value for this chunk
        uint32_t a = h[0], b = h[1], c = h[2], d = h[3];
        uint32_t e = h[4], f = h[5], g = h[6], hh = h[7];

        // Main loop of SHA-256
        for (size_t j = 0; j < 64; ++j) {
            uint32_t S1 = (e >> 6) ^ (e >> 11) ^ (e >> 25);
            uint32_t ch = (e & f) ^ ((~e) & g);
            uint32_t temp1 = hh + S1 + ch + custom_constants[j] + w[j];
            uint32_t S0 = (a >> 2) ^ (a >> 13) ^ (a >> 22);
            uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
            uint32_t temp2 = S0 + maj;

            hh = g;
            g = f;
            f = e;
            e = d + temp1;
            d = c;
            c = b;
            b = a;
            a = temp1 + temp2;
        }

        // Update hash values
        h[0] += a;
        h[1] += b;
        h[2] += c;
        h[3] += d;
        h[4] += e;
        h[5] += f;
        h[6] += g;
        h[7] += hh;
    }

    // Prepare the final hash result
    result << std::hex << std::setw(8) << std::setfill('0') << h[0]
           << std::hex << std::setw(8) << std::setfill('0') << h[1]
           << std::hex << std::setw(8) << std::setfill('0') << h[2]
           << std::hex << std::setw(8) << std::setfill('0') << h[3]
           << std::hex << std::setw(8) << std::setfill('0') << h[4]
           << std::hex << std::setw(8) << std::setfill('0') << h[5]
           << std::hex << std::setw(8) << std::setfill('0') << h[6]
           << std::hex << std::setw(8) << std::setfill('0') << h[7];

    return result.str();
}

int main() {
    // Replace the file path with the path to your PDF file
    std::ifstream file("C:/Rajeshwar/FinalProject/Bible.pdf", std::ios::binary);
    if (!file) {
        std::cerr << "Failed to open file. Exiting." << std::endl;
        return 1;
    }

    // Read the content of the file into a vector
    std::vector<uint8_t> inputData(
        (std::istreambuf_iterator<char>(file)),
        (std::istreambuf_iterator<char>()));

    // Calculate the custom SHA-256 hash
    std::string hashResult = calculate_custom_sha256(inputData);

    // Output the result
    std::cout << "Custom SHA-256 Hash: " << hashResult << std::endl;
}
